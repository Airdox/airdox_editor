/**
 * Transport contract between the stem engine and the editor.
 *
 * These are the *only* shapes allowed to cross an IPC/HTTP boundary. They live
 * in their own module because both sides need them: the renderer (type-only
 * import, no Node dependencies) and `src/stems/stemJobService.ts` (the
 * implementation). Nothing here may import `node:*` – that is what keeps the
 * browser bundle free of the engine's file system code, and it is asserted by
 * `tests/stem-engine-ipc-contract.test.ts`.
 */
import type { ComputeDevice, JobStatus, ModelFamily, QualityProfile, StemId } from './types';

/** Serializable per-stem result of a finished job. */
export interface StemJobStemView {
  id: StemId;
  displayName?: string;
  filePath: string;
  sha256: string;
  frames: number;
  sampleRate: number;
  channels: number;
  peak: number;
}

/** One separation job as the UI sees it. */
export interface StemJobView {
  jobId: string;
  /** Engine job id (`job_…`), known once the first progress event arrives. */
  engineJobId?: string;
  status: JobStatus;
  percent: number;
  phase: string;
  processedSeconds: number;
  totalSeconds: number;
  profile: QualityProfile;
  modelId: string;
  /** Model family that actually ran this job (e.g. `bs_roformer`, `htdemucs`). */
  family: ModelFamily;
  /** Stem ids exactly as the model descriptor declares them – never a constant. */
  stems: StemId[];
  chunkCount: number;
  cacheHit: boolean;
  trackName: string;
  createdAt: number;
  updatedAt: number;
  finishedAt?: number;
  error?: { code: string; message: string };
  /**
   * Rechengerät, das wirklich gerechnet hat (`cpu`, `directml`, `cuda`, …).
   * Die UI zeigt daraus „Verarbeitung läuft – GPU/CPU“ statt zu raten (§13).
   */
  device?: ComputeDevice;
  /** True, wenn auf CPU ausgewichen wurde (DirectML/CUDA nicht nutzbar). */
  cpuFallback?: boolean;
  /** Grund des Ausweichens, z. B. „DirectML-Treiberabsturz“. */
  fallbackReason?: string;
  /** Backend-Kennung des Laufs (`local-mdx` = ONNX-DJ-Pfad, `bs_roformer`, …). */
  backend?: string;
  /** Set only for a COMPLETED job. */
  result?: {
    outputDir: string;
    metadataPath: string;
    stems: StemJobStemView[];
    validationPass: boolean;
    recombinationErrorDb?: number;
    originalUnchanged: boolean;
    trainedModel: boolean;
  };
}

/**
 * Rechengerät einer Separation. Bewusst derselbe Typ wie in der Engine
 * (`ComputeDevice`), damit UI und Engine nicht auseinanderlaufen –
 * `directml`/`coreml` sind die ONNX-GPU-Pfade.
 */
export type StemComputeDevice = ComputeDevice;

/** Validierungstiefe: live (schnell) oder Studio (volle Grenzanalyse). */
export type StemValidationMode = 'fast_dj' | 'studio_master';

export interface StemProfileInfo {
  profile: QualityProfile;
  modelId: string;
  family: string;
  stems: { id: StemId; displayName: string }[];
  available: boolean;
  reason?: string;
  description: string;
  parameters: { numOverlap: number; ensemblePasses: number };
}

/** One selectable model family (architecture) as the settings UI sees it. */
export interface StemFamilyInfo {
  family: ModelFamily;
  /** Human readable label, e.g. "BS-RoFormer". Never hard coded in the UI. */
  label: string;
  description: string;
  /** True when at least one model of this family is installed and usable. */
  available: boolean;
  reason?: string;
  /** Profiles at least one model of this family can serve. */
  serves: QualityProfile[];
  /** Model ids belonging to this family, best (primary) first. */
  modelIds: string[];
}

export interface StemServiceStatus {
  ok: boolean;
  /** False when no profile can run (missing model or missing runtime). */
  usable: boolean;
  profiles: StemProfileInfo[];
  defaultProfile: QualityProfile;
  /** Every model family registered in the catalog, with availability per family. */
  families: StemFamilyInfo[];
  models: {
    id: string;
    family: string;
    version: string;
    /** Checkpoint format (`onnx` = läuft in-process, `safetensors-package`/`demucs-th` = Subprozess). */
    format?: string;
    installed: boolean;
    hashVerified: boolean;
    reason?: string;
    stems: StemId[];
    serves: QualityProfile[];
  }[];
  backends: { kind: string; name: string; available: boolean; reason?: string }[];
  /**
   * In-process ONNX runtime (DJ path): which execution providers the installed
   * `onnxruntime-node` can use and whether it loads at all. The settings menu
   * shows this instead of letting the user pick a device that cannot work.
   */
  onnx?: {
    runtimeAvailable: boolean;
    /** Chosen provider order, e.g. ['dml', 'cpu']. */
    providers: string[];
    /** Providers the shipped runtime carries, with bundle flag. */
    supported: { name: string; bundled: boolean }[];
    /** ONNX descriptor the DJ path would use, if the catalog has one. */
    modelId?: string;
    modelInstalled: boolean;
    reason?: string;
  };
  cacheEntries: { key: string; stems: number }[];
  roots: Record<'working' | 'output' | 'cache' | 'models' | 'staging', string>;
  registryIssues: unknown[];
  accessMode: 'ORIGINALS_READ_ONLY';
}

export type StemServiceEventType = 'progress' | 'completed' | 'cancelled' | 'failed';

export interface StemServiceEvent {
  type: StemServiceEventType;
  job: StemJobView;
}

export interface StartStemJobPayload {
  /** WAV bytes of the working copy; staged by the engine, never next to the original. */
  bytes?: Uint8Array;
  /** Alternative to `bytes`: a file inside the engine data directory. */
  inputPath?: string;
  trackName?: string;
  profile?: QualityProfile;
  /**
   * Explicit model/architecture. Wins over the profile default – that is what
   * the settings menu sends when the user pinned an architecture.
   */
  modelId?: string;
  /**
   * Explicit model family (architecture) to use, e.g. `bs_roformer`,
   * `mel_band_roformer`, `htdemucs`. When set without `modelId`, the engine
   * resolves the best model of that family for `profile`; when set together
   * with `modelId`, a mismatch is rejected with `MODEL_INCOMPATIBLE`.
   */
  family?: ModelFamily;
  stems?: StemId[];
  device?: StemComputeDevice;
  /** Validation depth for this job. `fast_dj` skips the boundary analysis. */
  mode?: StemValidationMode;
  precision?: 'native' | 'f32' | 'f16' | 'bf16' | 'q8_0';
  overlap?: number;
  chunkSizeSamples?: number;
  clipMode?: 'none' | 'rescale';
  dcRemoval?: boolean;
}

/**
 * Bridge results: a rejected promise over IPC loses its error code, so every
 * failure is a *value* here. `data` is a single nested field on purpose – an
 * intersection like `{ ok: true } & T` cannot be narrowed by `if (!result.ok)`
 * whenever `T` itself carries a boolean, and that narrowing is exactly what the
 * renderer relies on.
 */
export type StemBridgeError = { ok: false; code: string; message: string; details?: Record<string, unknown> };
export type StemBridgeResult<T> = { ok: true; data: T } | StemBridgeError;

/**
 * What `electron/preload.cjs` exposes and what `src/audio/stemEngine.ts`
 * expects. Kept as one interface so a missing method is a compile error rather
 * than a runtime `is not a function`.
 */
export interface StemDesktopApi {
  getStemEngineStatus(): Promise<StemBridgeResult<StemServiceStatus>>;
  startStemJob(payload: StartStemJobPayload): Promise<StemBridgeResult<StemJobView>>;
  waitStemJob(jobId: string): Promise<StemBridgeResult<StemJobView>>;
  getStemJob(jobId: string): Promise<StemBridgeResult<StemJobView | null>>;
  listStemJobs(): Promise<StemBridgeResult<StemJobView[]>>;
  cancelStemJob(jobId: string, reason?: string): Promise<StemBridgeResult<{ accepted: boolean }>>;
  pauseStemJob(jobId: string): Promise<StemBridgeResult<{ accepted: boolean }>>;
  resumeStemJob(jobId: string): Promise<StemBridgeResult<{ accepted: boolean }>>;
  readStemJobStem(jobId: string, stemId: StemId): Promise<StemBridgeResult<{ stemId: StemId; wav: Uint8Array }>>;
  readStemJobMetadata(jobId: string): Promise<StemBridgeResult<{ metadata: unknown }>>;
  onStemJobProgress(listener: (event: StemServiceEvent) => void): () => void;

  /*
   * High-Quality-Pfad extern (Google Drive + Colab-Worker, §15).
   *
   * Absichtlich optional (`?`): eine ältere Brücke ohne Fernpfad soll den
   * Editor nicht unbrauchbar machen. Der Renderer prüft auf Vorhandensein,
   * statt eine Exception zu ernten – und meldet dann „Fernpfad nicht
   * verfügbar“ statt „function is not a function“.
   *
   * Die Methoden liegen hier flach, weil die IPC-Brücke sie flach exponiert
   * (`window.rekordboxDesktop.stemEngine.remoteStatus()`), genau wie die
   * lokalen Job-Methoden. `StemRemoteApi` beschreibt dieselbe Gruppe als
   * eigener Typ (z. B. für den HTTP-Client).
   */
  remoteStatus?(): Promise<StemBridgeResult<RemoteServiceStatus>>;
  startRemoteStemJob?(payload: StartRemoteStemJobPayload): Promise<StemBridgeResult<RemoteStemJobView>>;
  listRemoteStemJobs?(): Promise<StemBridgeResult<RemoteStemJobView[]>>;
  pollRemoteStemJobs?(): Promise<StemBridgeResult<RemoteServiceStatus>>;
  cancelRemoteStemJob?(jobId: string, reason?: string): Promise<StemBridgeResult<{ accepted: boolean }>>;
  resumeRemoteStemJobs?(): Promise<StemBridgeResult<RemoteServiceStatus>>;
  configureRemoteStemJobs?(settings: RemoteSettings): Promise<StemBridgeResult<RemoteServiceStatus>>;
  onRemoteStemJobProgress?(listener: (event: RemoteServiceEvent) => void): () => void;
}

/* ------------------------------------------------------------------------- *
 * Remote-Pfad (High Quality extern über Google Drive / Colab-Worker)
 * ------------------------------------------------------------------------- */

/**
 * Job-Status im Fernpfad. Bewusst **dieselben** Werte wie {@link JobStatus}:
 * ein zweites, konkurrierendes Statussystem wäre genau das, was §14 verbietet.
 * Der Fernpfad hat zusätzlich Phasen (z. B. „FALLBACK_CPU“, „WARTET_AUF_WORKER“),
 * die in `phase`/`device` stehen – nicht im Status.
 */
export type RemoteJobStatus = JobStatus;

export interface RemoteStemJobView {
  /** Fern-Job-Id (UUID) – dieselbe in Manifest, Logs und Ergebnissen (§18). */
  jobId: string;
  status: RemoteJobStatus;
  phase: string;
  percent: number;
  profile: QualityProfile;
  modelId: string;
  family: ModelFamily;
  /** Backend des Fern-Workers, z. B. `bs_roformer`. */
  backend: string;
  stems: StemId[];
  trackName: string;
  createdAt: number;
  updatedAt: number;
  finishedAt?: number;
  /** lokaler Job, über den die Stems in den Editor kommen (nach COMPLETED). */
  localJobId?: string;
  /** Rechenort des Workers: GPU/CPU inkl. Fallback-Kennzeichnung. */
  device?: ComputeDevice;
  cpuFallback?: boolean;
  fallbackReason?: string;
  worker?: { id: string; claimedAt?: number; heartbeatAt?: number; host?: string };
  /** Fortschritt des Workers, wenn er welchen meldet. */
  workerPercent?: number;
  attempts?: number;
  error?: { code: string; message: string };
  /** Grundeinstellungen des Transports (Anzeige: „Google Drive (Ordner)“). */
  transport?: string;
  /** True, wenn der letzte Poll den Transport nicht erreichen konnte (§21 C). */
  transportDegraded?: boolean;
  /** Lokal vorhandene Ergebnisse (nach Import), damit die UI nichts nachfragen muss. */
  importedStems?: { id: StemId; filePath: string; bytes: number; sha256: string }[];
}

export interface RemoteServiceStatus {
  /** True, wenn ein Transport konfiguriert ist (Ordner oder rclone-Remote). */
  configured: boolean;
  /** `folder` = Google-Drive-Sync-Ordner/rclone-Mount, `rclone` = rclone-Remote. */
  kind?: 'folder' | 'rclone';
  /** Anzeigename, z. B. „Google Drive (Ordner)“ – nie ein Zugangstoken. */
  label?: string;
  /** Wo Jobs liegen (für Anzeige/Support; kein Geheimnis). */
  root?: string;
  reason?: string;
  /** True, wenn der Transport gerade erreichbar ist. */
  reachable: boolean;
  jobs: RemoteStemJobView[];
  active: number;
  completed: number;
  failed: number;
  /** Empfohlenes Polling-Intervall (ms) – der Editor fragt nicht schneller. */
  pollIntervalMs: number;
}

export interface RemoteSettings {
  kind?: 'folder' | 'rclone';
  /** Ordner (Drive-Sync/rclone-Mount) bzw. rclone-Remote-Pfad (`gdrive:airdox-stem-jobs`). */
  root?: string;
  pollIntervalMs?: number;
  /** Kulanz, bevor ein job ohne Worker-Lebenszeichen als FAILED gilt (§21 E). */
  workerLeaseMs?: number;
  /** Absolute Obergrenze für einen Fern-Job (§21 E). */
  jobTimeoutMs?: number;
}

export interface StartRemoteStemJobPayload {
  /** Arbeitskopie (WAV) – wird hochgeladen, das Original bleibt unberührt. */
  bytes?: Uint8Array;
  /** Alternative: Pfad im Engine-Datenordner (dann wird eine Arbeitskopie gezogen). */
  inputPath?: string;
  trackName?: string;
  profile?: QualityProfile;
  modelId?: string;
  family?: ModelFamily;
  /** Rechenort-Wunsch des Workers (`auto` = GPU wenn möglich, sonst CPU). */
  device?: StemComputeDevice;
  mode?: StemValidationMode;
}

export interface RemoteServiceEvent {
  type: 'progress' | 'completed' | 'failed' | 'cancelled' | 'transport';
  job: RemoteStemJobView;
}

/** Der Teil des Remote-Pfads, der über IPC/HTTP läuft (Gruppierung, s. o.). */
export interface StemRemoteApi {
  remoteStatus(): Promise<StemBridgeResult<RemoteServiceStatus>>;
  startRemoteStemJob(payload: StartRemoteStemJobPayload): Promise<StemBridgeResult<RemoteStemJobView>>;
  listRemoteStemJobs(): Promise<StemBridgeResult<RemoteStemJobView[]>>;
  /** Ein Poll-Zyklus (lädt fertige Ergebnisse automatisch herunter und importiert sie). */
  pollRemoteStemJobs(): Promise<StemBridgeResult<RemoteServiceStatus>>;
  cancelRemoteStemJob(jobId: string, reason?: string): Promise<StemBridgeResult<{ accepted: boolean }>>;
  /** Erneutes Anwenden des zuletzt gespeicherten Zustands (Editor-Neustart, §32). */
  resumeRemoteStemJobs(): Promise<StemBridgeResult<RemoteServiceStatus>>;
  configureRemoteStemJobs(settings: RemoteSettings): Promise<StemBridgeResult<RemoteServiceStatus>>;
}
